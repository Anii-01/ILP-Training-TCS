package com.bill;
import java.util.*;

public class billconsumer {
		private String consumer_id;
          private String bill_id;
          private int bill;
          private String date;
		public billconsumer(String consumer_id, String bill_id, int bill, String date) {

			this.consumer_id = consumer_id;
			this.bill_id = bill_id;
			this.bill = bill;
			this.date = date;
		}
		public String getConsumer_id() {
			return consumer_id;
		}
		public void setConsumer_id(String consumer_id) {
			this.consumer_id = consumer_id;
		}
		public String getBill_id() {
			return bill_id;
		}
		public void setBill_id(String bill_id) {
			this.bill_id = bill_id;
		}
		public int getBill() {
			return bill;
		}
		public void setBill(int bill) {
			this.bill = bill;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String toString() {
			return "billconsumer [consumer_id=" + consumer_id + ", bill_id=" + bill_id + ", bill=" + bill + ", date=" + date
					+ "]";
		}
           
}
