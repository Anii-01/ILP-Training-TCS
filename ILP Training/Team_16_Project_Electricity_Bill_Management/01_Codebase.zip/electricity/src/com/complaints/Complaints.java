package com.complaints;

public class Complaints {
	String complaintType;
	String category;
	String contactPerson;
	String landmark;
	String consumerNo;
	String problemDescription;
	String mobileNo;
	String address;
	public Complaints(String complaintType, String category, String contactPerson, String landmark, String consumerNo,
			String problemDescription, String mobileNo, String address) {
		super();
		this.complaintType = complaintType;
		this.category = category;
		this.contactPerson = contactPerson;
		this.landmark = landmark;
		this.consumerNo = consumerNo;
		this.problemDescription = problemDescription;
		this.mobileNo = mobileNo;
		this.address = address;
	}
	public String getComplaintType() {
		return complaintType;
	}
	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getProblemDescription() {
		return problemDescription;
	}
	public void setProblemDescription(String problemDescription) {
		this.problemDescription = problemDescription;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
