package com.complaintserv;
import com.complaints.Complaints;
import java.util.*;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.*;
import java.sql.*;
import com.customerinfo.customer;
import com.customerservice.daoservice;

@WebServlet("/complain")
public class complain extends HttpServlet {
	 protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        String complaintType = req.getParameter("complaintType");
	        String category = req.getParameter("category");
	        String contactPerson = req.getParameter("contactPerson");
	        String landmark = req.getParameter("landmark");
	        String consumerNo = req.getParameter("consumerNo");
	        String problemDescription = req.getParameter("problemDescription");
	        String mobileNo = req.getParameter("mobileNo");
	        String address = req.getParameter("address");

	        Complaints com = new Complaints(complaintType, category, contactPerson, landmark, consumerNo, problemDescription, mobileNo, address);
	        System.out.println(com.toString());
	        try{
	        boolean inserted = daoservice.insertcomplaint(com);
	        System.out.println(inserted);

	        if (inserted) {
	            //System.out.println("Inserted successfully");
	            req.getRequestDispatcher("complaint-status.html").forward(req, resp);
	        } else {
	            System.out.println("Insertion failed");
	        }
	        }
	        catch(Exception e)
	        {
	        	System.out.println(e);
	        }
	    }
}
