package com.customerinfo;

public class customer {
		 private String Consumer_Id;
		 private String Bill_Number;
		 private String Title;
		 private String Customer_Name;
		 private String Email;
		 private String Mobile_Number;
		 private String User_Id;
		 private String Password;
		 
		 
		 
	public customer(String consumer_Id, String bill_Number, String title, String customer_Name, String email,
				String mobile_Number, String user_Id, String password) {
		
			this.Consumer_Id = consumer_Id;
			this.Bill_Number = bill_Number;
			this.Title = title;
			this.Customer_Name = customer_Name;
			this.Email = email;
			this.Mobile_Number = mobile_Number;
			this.User_Id = user_Id;
			this.Password = password;
			
			
		}



	public String getConsumer_Id() {
		return Consumer_Id;
	}



	public void setConsumer_Id(String consumer_Id) {
		Consumer_Id = consumer_Id;
	}



	public String getBill_Number() {
		return Bill_Number;
	}



	public void setBill_Number(String bill_Number) {
		Bill_Number = bill_Number;
	}



	public String getTitle() {
		return Title;
	}



	public void setTitle(String title) {
		Title = title;
	}



	public String getCustomer_Name() {
		return Customer_Name;
	}



	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}



	public String getEmail() {
		return Email;
	}



	public void setEmail(String email) {
		Email = email;
	}



	public String getMobile_Number() {
		return Mobile_Number;
	}



	public void setMobile_Number(String mobile_Number) {
		Mobile_Number = mobile_Number;
	}



	public String getUser_Id() {
		return User_Id;
	}



	public void setUser_Id(String user_Id) {
		User_Id = user_Id;
	}



	public String getPassword() {
		return Password;
	}



	public void setPassword(String password) {
		Password = password;
	}



	

		 
	}


