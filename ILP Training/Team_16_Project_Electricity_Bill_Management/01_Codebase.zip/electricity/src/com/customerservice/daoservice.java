package com.customerservice;
import com.customerinfo.customer;
import com.dbaseoperations.dao;
import java.sql.*;
import java.util.*;
import com.bill.billconsumer;
import com.complaints.Complaints;
public class daoservice {
	public static boolean insert(customer customerinfo) throws ClassNotFoundException, SQLException {
		return dao.insert(customerinfo);
	}
	
	public static boolean get(String user,String password) throws ClassNotFoundException, SQLException {
		return dao.get(user,password);
	}
	public static String getname(String user,String password) throws ClassNotFoundException, SQLException{
		return dao.getname(user,password);
	}
	public static String getconsumerid(String user,String password) throws ClassNotFoundException, SQLException{
		return dao.getconsumerid(user,password);
	}
	public static ArrayList<billconsumer> getbill(String consumerid) throws ClassNotFoundException, SQLException
	{
		return dao.getbill(consumerid);
	}
	public static boolean paid(String[] s) throws ClassNotFoundException, SQLException
	
	{
		return dao.paid(s);
	}
	public static boolean insertcomplaint(Complaints complaint)throws ClassNotFoundException, SQLException {
		return dao.insertcomplaint(complaint);
	}

}
