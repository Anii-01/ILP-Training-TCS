package com.dbaseoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.helpher.helpdbms;
import com.customerinfo.customer;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.*;
import com.bill.billconsumer;
import com.complaints.Complaints;
public class dao {
	public static boolean insert(customer customerInfo) throws ClassNotFoundException, SQLException {
		boolean isInserted = false;
		String sql = "insert into customer(CustomerID,billno,Title,CustomerName,Email,mobileno,Userid,Password,userStatus,userType) values (?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		preparedStatement.setString(1,customerInfo.getConsumer_Id());
		preparedStatement.setString(2, customerInfo.getBill_Number());
		preparedStatement.setString(3, customerInfo.getTitle());
		preparedStatement.setString(4, customerInfo.getCustomer_Name());
		preparedStatement.setString(5, customerInfo.getEmail());
		preparedStatement.setString(6, customerInfo.getMobile_Number());
		preparedStatement.setString(7, customerInfo.getUser_Id());
		preparedStatement.setString(8, customerInfo.getPassword());
		preparedStatement.setString(9, "user");
		preparedStatement.setString(10, "active");

		int noOfRowsAffected = preparedStatement.executeUpdate();
		 
		if (noOfRowsAffected >= 1) {
			System.out.println("insert");
			isInserted = true;
		}

		helpdbms.closePreparedStatement();
		
		return isInserted;
	}
	public static boolean get(String user,String password) throws ClassNotFoundException, SQLException
	{
		boolean found=false;
		String sql="SELECT USERID,PASSWORD FROM CUSTOMER WHERE Userid=? and Password=?";
		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		preparedStatement.setString(1,user);
		preparedStatement.setString(2,password);
		ResultSet r=preparedStatement.executeQuery();
	    if(r.next())
	    {
	    	found=true;
	    }
	    return found;
	}
	public static String getname(String user,String password) throws ClassNotFoundException, SQLException{
		String name="";
		String sql="SELECT CUSTOMERNAME FROM CUSTOMER WHERE Userid=? and Password=?";
		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		preparedStatement.setString(1,user);
		preparedStatement.setString(2,password);
		ResultSet r=preparedStatement.executeQuery();
		if(r.next())
		{
			name=r.getString(1);
		}
		return name;
	}
	public static String getconsumerid(String user,String password) throws ClassNotFoundException, SQLException{
		String consumerid="";
		String sql="SELECT CUSTOMERID FROM CUSTOMER WHERE Userid=? and Password=?";
		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		preparedStatement.setString(1,user);
		preparedStatement.setString(2,password);
		ResultSet r=preparedStatement.executeQuery();
		if(r.next())
		{
			consumerid=r.getString(1);
		}
		return consumerid;
	}
	public static ArrayList<billconsumer> getbill(String consumerid) throws ClassNotFoundException, SQLException
	{
		ArrayList<billconsumer> a=new ArrayList<>();
		String sql="select * from bill where consumer_id=? and pay='unpaid' ";
		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		preparedStatement.setString(1,consumerid);
		ResultSet r=preparedStatement.executeQuery();
		while(r.next())
		{
			billconsumer b=new billconsumer(r.getString(1),r.getString(2),r.getInt(3),String.valueOf(r.getDate(4)));
			a.add(b);
		}
		return a;
	}
	public static boolean paid(String[] s) throws ClassNotFoundException, SQLException
	{
		String sql="update bill set pay='paid' where bill_id in";
		String ques="(?";
		for(int i=1;i<s.length;i++)
		{
			ques=ques.concat(",?");
		}
		ques=ques.concat(")");
		sql=sql.concat(ques);
		PreparedStatement preparedStatement = helpdbms.getPreparedStatement(sql);
		for(int i=0;i<s.length;i++)
		{
			preparedStatement.setString(i+1, s[i]);
		}
		int re=preparedStatement.executeUpdate();
		if(re>=1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	String str = "";
	public void deactivateAccount(String str)
	{
		
	}
	public static boolean insertcomplaint(Complaints complaint)throws ClassNotFoundException, SQLException {
        int successCount = 0;
        boolean id = false;
        String sql=  "INSERT INTO Complaints (complaint_type, category, contact_person, land_mark, consumer_no, problem_description, mobile_no, address) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        // Use try-with-resources to automatically close the resources
        PreparedStatement ps= helpdbms.getPreparedStatement(sql);
    
             
            ps.setString(1, complaint.getComplaintType());
            ps.setString(2, complaint.getCategory());
            ps.setString(3, complaint.getContactPerson());
            ps.setString(4, complaint.getLandmark());
            ps.setString(5, complaint.getConsumerNo());  // Assuming consumer_no is a long
            ps.setString(6, complaint.getProblemDescription());
            ps.setString(7, complaint.getMobileNo());     // Assuming mobile_no is a long
            ps.setString(8, complaint.getAddress());
            
            successCount = ps.executeUpdate();
            
            if (successCount > 0) {
                id = true;
            }
           
        
        return id;
    }
}
