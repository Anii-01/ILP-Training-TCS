package com.helpher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
public class helpdbms {
	 private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static Statement statement;
	public static PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException, SQLException {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
	   connection = DriverManager.getConnection("jdbc:derby:D:\\Users\\2727540\\MyDB;create=true","","");
		preparedStatement = connection.prepareStatement(sql);
		return preparedStatement;
	}
	public static Statement getStatement() throws ClassNotFoundException, SQLException {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
	   connection = DriverManager.getConnection("jdbc:derby:C:\\Users\\rohit\\MyDB;create=true","","");
		statement = connection.createStatement();
		return statement;
	}
	
	
	public static void closePreparedStatement() throws SQLException {
		preparedStatement.close();
		connection.close();
	}
	
}
