package com.loginuser;
import java.util.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.*;
import java.sql.*;
import com.customerinfo.customer;
import com.customerservice.daoservice;
import com.bill.billconsumer;
@WebServlet("/login")
public class login extends HttpServlet {
	static RequestDispatcher dis;
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
		String user=req.getParameter("userID");
		String password=req.getParameter("password");
		try{
	    boolean r=daoservice.get(user, password);
	    String name=daoservice.getname(user, password);
	    String consumer_id=daoservice.getconsumerid(user,password);
	    ArrayList<billconsumer> a=daoservice.getbill(consumer_id);
	    
	    HttpSession session=req.getSession();
	    session.setAttribute("customername", name);
	    session.setAttribute("customerid",consumer_id);
	    session.setAttribute("billdetails",a);
	    if(r==true)
	    {
	    	dis=req.getRequestDispatcher("home.jsp");
	    	dis.forward(req, res);
	    
	    }
	    else
	    {
	    	req.setAttribute("loginerror", "1");
	    	dis=req.getRequestDispatcher("login.jsp");
	    	dis.forward(req, res);
	    }
		}
		catch(SQLException | ClassNotFoundException e)
		{
			System.out.println(e);
		}
	}
	
}
