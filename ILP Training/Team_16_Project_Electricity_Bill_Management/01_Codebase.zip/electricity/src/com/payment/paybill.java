package com.payment;
import java.util.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.*;
import java.sql.*;
import com.customerinfo.customer;
import com.customerservice.daoservice;
import com.bill.billconsumer;
@WebServlet("/paybill")
public class paybill extends HttpServlet {
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
		HttpSession h=req.getSession();
		String items=(String)h.getAttribute("items");
		String[] s=items.split(",");
		
		ArrayList<billconsumer> a=(ArrayList<billconsumer>) h.getAttribute("billdetails");
		
		for(int i=0;i<a.size();i++)
		{
			if(items.contains(a.get(i).getBill_id()))
			{
				a.remove(i);
			}
		}
		req.setAttribute("billdetails", a);
		try{
		boolean delete=daoservice.paid(s);
		RequestDispatcher disp=req.getRequestDispatcher("home.jsp");
		if(delete==true)
		{
			 req.setAttribute("result1","1");
			   disp.forward(req, res);
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
}
