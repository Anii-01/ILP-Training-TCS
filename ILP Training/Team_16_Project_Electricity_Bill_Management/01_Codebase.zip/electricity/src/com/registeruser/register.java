package com.registeruser;
import java.util.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.*;
import java.sql.*;
import com.customerinfo.customer;
import com.customerservice.daoservice;
@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
		   String consumer_id=req.getParameter("customerID");
		   String bill_number=req.getParameter("billNumber");
		   String title=req.getParameter("title");
		   String Name=req.getParameter("name");
		   String email=req.getParameter("emailaddress");
		   String mobile=req.getParameter("mobile");
		   String userid=req.getParameter("userId");
		   String password=req.getParameter("password");
		   customer c=new customer(consumer_id,bill_number,title,Name,email,mobile,userid,password);
		   try
		   {
		   boolean r=daoservice.insert(c);
		   String r1=String.valueOf(r);
//		   if(r==true)
//		   {
//			   System.out.println("inserted successfully");
//		   }
//		   else
//		   {
//			   System.out.println("No");
//		   }
//		   }
		   req.setAttribute("result",r1);
		   req.setAttribute("insertsuccessfully","1");
		   req.setAttribute("consumerid", consumer_id);
		   RequestDispatcher disp=req.getRequestDispatcher("register.jsp");
		   disp.forward(req, res);
		   }
		   
		   catch(SQLException|ClassNotFoundException e)
		   {
			   System.out.println(e);
		   }
     	   
   }
}
