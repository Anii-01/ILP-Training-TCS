select *from CUSTOMER;


select * from BILL;

INSERT INTO Bill VALUES ('123456789', '12345', 5000, '2024-09-01', 'unpaid');

delete from bill where bill_id = '12345';
delete from bill where bill_id = '12344';
delete from bill where bill_id = '12343';

INSERT INTO Bill VALUES ('123456789', '12345', 5000, '2024-09-01', 'unpaid');
INSERT INTO Bill VALUES ('123456789', '12344', 4000, '2024-06-02', 'unpaid');
INSERT INTO Bill VALUES ('123456789', '12343', 700, '2024-07-01', 'unpaid');


INSERT INTO Bill VALUES ('6767676767', '12349', 1500, '2024-06-02', 'unpaid');
INSERT INTO Bill VALUES ('6767676767', '12348', 1700, '2024-07-01', 'unpaid');
